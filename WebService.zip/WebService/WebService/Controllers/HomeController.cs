﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebService.Models;

namespace WebService.Controllers
{
    public class HomeController : Controller
    {

        EmployeeEntities Emp = new EmployeeEntities();

        public ActionResult Index()
        {
            EmpDetController empcon = new EmpDetController();
            empcon.Get();
        
            ViewBag.Title = "Home Page";

            return View();
        }
    }
}

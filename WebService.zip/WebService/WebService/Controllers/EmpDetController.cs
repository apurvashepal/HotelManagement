﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebService.Models;

namespace WebService.Controllers
{
    public class EmpDetController : ApiController
    {
      public static  List<EmployeeEntities> EmpDet = new List<EmployeeEntities>();

       
        EmployeeEntities dbcon = new EmployeeEntities();
      //   new EmployeeDet { EmployeeEntties.Id = 1, name ="Apurva" Dept ="Microsoft"};

        public IEnumerable<EmployeeEntities> Get()
        {
            return EmpDet;
        }

        public List<EmployeeEntities> Post(EmployeeEntities Emp)
        {
            EmpDet.Add(Emp);
            return EmpDet;
        }

     /*   public void Put(EmployeeEntities Emp)
        {
            EmployeeEntities EmpObj=( from emp in EmpDet where emp.Id == Emp.Id select emp);
            EmpObj.name = Emp.name;
        }
       public void Delete (int id)
        {
            EmpDet.Remove(temp => temp.Id == id);
        }
    */
    
    }

}

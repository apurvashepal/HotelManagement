﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelManagement.Models
{
    public class Roommodel
    {

        public int id { get; set;}
        public string RoomType { get; set; }
        public int num_rooms
        {
            get { return num_rooms; }
            set { num_rooms = Numberroom(RoomType); } 
        }
        public int price { get; 
            set {
                price = Calculateprice(RoomType, quantity);
        } }
        public int quantity { get; 
            set {
            if (quantity > num_rooms)
            {
                Console.WriteLine("rooms not available");
            }

            } }




       
       



    } 
}
﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class RoomController : Controller
    {
        //
        // GET: /Room/
       
        [HttpPost]
        public ActionResult Index()
        {

            List<Roommodel> Roomdetails = new List<Roommodel>();

            return View();
        }
        public ActionResult CrudRoom(string RoomType)
        {
            return View();
        }
        private int Calculateprice(String Roomtype, int quantity)
        {
            if (RoomType == "Standard")
            { return 2000 * quantity; }
            if (RoomType == "Premium")
            { return 3000 * quantity; }
            if (RoomType == "Delux")
            { return 4000 * quantity; }
        }



        private int Numberroom(String Roomtype)
        {
            if (RoomType == "Standard")
            { return 10; }
            if (RoomType == "Premium")
            { return 15; }
            if (RoomType == "Delux")
            { return 5; }
        }

        public string RoomType { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class EmployeeController : ApiController
    {
        EmployeeEntities Conn = new EmployeeEntities();
        List<EmployeeEntities> EmpList = new List<EmployeeEntities>();
        public List<EmployeeEntities> GetDetails ()
        {

            return Conn.EmployeeDetails.ToList();
        }

    }
}
